getMicrosoftLanguages <-
function(){
    getLanguages('Microsoft')
}
