getGoogleLanguages <-
function(){
    getLanguages('Google')
}
